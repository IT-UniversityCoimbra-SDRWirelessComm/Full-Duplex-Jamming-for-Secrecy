#!/bin/bash

for i in {1..50}; do mkdir $i; done