#!/bin/bash

for num in {1..38}
do
   echo "=================FICHEIRO $num================="
   mkdir threshold10/$num 
   cp $num/EVE_55_8000.txt threshold10/$num 
done
