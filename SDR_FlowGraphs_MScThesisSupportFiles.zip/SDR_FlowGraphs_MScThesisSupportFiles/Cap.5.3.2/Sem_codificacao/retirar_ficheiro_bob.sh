#!/bin/bash

for num in {1..45}
do
   echo "=================FICHEIRO $num================="
   mkdir threshold10/$num
   cp $num/BOB_55_8000.txt threshold10/$num 
done
