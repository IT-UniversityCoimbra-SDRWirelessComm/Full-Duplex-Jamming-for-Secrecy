#!/bin/bash

for num in {1..38}
do
	echo "=================TESTE $num================="
   python -u eve_dec.py $num 10
done
