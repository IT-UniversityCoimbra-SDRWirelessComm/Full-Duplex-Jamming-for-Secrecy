#!/bin/bash

for i in {1..45}; do mkdir $i; done