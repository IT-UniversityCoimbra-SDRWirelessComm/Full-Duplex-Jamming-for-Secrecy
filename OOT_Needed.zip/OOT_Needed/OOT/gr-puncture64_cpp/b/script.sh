#!/bin/bash
cmake ../
make
sudo make install
sudo ldconfig