var classgr_1_1puncture64__cpp_1_1depuncture64 =
[
    [ "sptr", "classgr_1_1puncture64__cpp_1_1depuncture64.html#a52f61930b68e58058e5259784f4ce5e2", null ],
    [ "make", "classgr_1_1puncture64__cpp_1_1depuncture64.html#ac25cfca5e23674ae9acf258418baf898", null ]
];