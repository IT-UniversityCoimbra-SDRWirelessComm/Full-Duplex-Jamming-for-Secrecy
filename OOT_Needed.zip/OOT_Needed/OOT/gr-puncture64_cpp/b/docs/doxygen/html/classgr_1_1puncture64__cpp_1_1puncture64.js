var classgr_1_1puncture64__cpp_1_1puncture64 =
[
    [ "sptr", "classgr_1_1puncture64__cpp_1_1puncture64.html#a8dada013c83f4bc6e38f439b42c3f2f3", null ],
    [ "make", "classgr_1_1puncture64__cpp_1_1puncture64.html#a8c94a85577ca776fb93a3f67465c68ea", null ]
];