var namespacegr =
[
    [ "puncture64_cpp", "namespacegr_1_1puncture64__cpp.html", "namespacegr_1_1puncture64__cpp" ]
];