var files =
[
    [ "api.h", "api_8h.html", "api_8h" ],
    [ "depuncture64.h", "depuncture64_8h.html", [
      [ "depuncture64", "classgr_1_1puncture64__cpp_1_1depuncture64.html", "classgr_1_1puncture64__cpp_1_1depuncture64" ]
    ] ],
    [ "depuncture64_impl.h", "depuncture64__impl_8h.html", [
      [ "depuncture64_impl", "classgr_1_1puncture64__cpp_1_1depuncture64__impl.html", "classgr_1_1puncture64__cpp_1_1depuncture64__impl" ]
    ] ],
    [ "puncture64.h", "puncture64_8h.html", [
      [ "puncture64", "classgr_1_1puncture64__cpp_1_1puncture64.html", "classgr_1_1puncture64__cpp_1_1puncture64" ]
    ] ],
    [ "puncture64_impl.h", "puncture64__impl_8h.html", [
      [ "puncture64_impl", "classgr_1_1puncture64__cpp_1_1puncture64__impl.html", "classgr_1_1puncture64__cpp_1_1puncture64__impl" ]
    ] ]
];