var namespacegr_1_1puncture64__cpp =
[
    [ "depuncture64", "classgr_1_1puncture64__cpp_1_1depuncture64.html", "classgr_1_1puncture64__cpp_1_1depuncture64" ],
    [ "depuncture64_impl", "classgr_1_1puncture64__cpp_1_1depuncture64__impl.html", "classgr_1_1puncture64__cpp_1_1depuncture64__impl" ],
    [ "puncture64", "classgr_1_1puncture64__cpp_1_1puncture64.html", "classgr_1_1puncture64__cpp_1_1puncture64" ],
    [ "puncture64_impl", "classgr_1_1puncture64__cpp_1_1puncture64__impl.html", "classgr_1_1puncture64__cpp_1_1puncture64__impl" ]
];