var hierarchy =
[
    [ "block", null, [
      [ "gr::puncture64_cpp::depuncture64", "classgr_1_1puncture64__cpp_1_1depuncture64.html", [
        [ "gr::puncture64_cpp::depuncture64_impl", "classgr_1_1puncture64__cpp_1_1depuncture64__impl.html", null ]
      ] ],
      [ "gr::puncture64_cpp::puncture64", "classgr_1_1puncture64__cpp_1_1puncture64.html", [
        [ "gr::puncture64_cpp::puncture64_impl", "classgr_1_1puncture64__cpp_1_1puncture64__impl.html", null ]
      ] ]
    ] ]
];