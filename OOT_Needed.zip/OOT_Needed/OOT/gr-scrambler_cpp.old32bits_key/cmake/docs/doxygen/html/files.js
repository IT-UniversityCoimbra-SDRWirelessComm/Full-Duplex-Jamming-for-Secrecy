var files =
[
    [ "api.h", "api_8h.html", "api_8h" ],
    [ "custom_descrambler.h", "custom__descrambler_8h.html", [
      [ "custom_descrambler", "classgr_1_1scrambler__cpp_1_1custom__descrambler.html", "classgr_1_1scrambler__cpp_1_1custom__descrambler" ]
    ] ],
    [ "custom_descrambler_impl.h", "custom__descrambler__impl_8h.html", [
      [ "custom_descrambler_impl", "classgr_1_1scrambler__cpp_1_1custom__descrambler__impl.html", "classgr_1_1scrambler__cpp_1_1custom__descrambler__impl" ]
    ] ],
    [ "custom_scrambler.h", "custom__scrambler_8h.html", [
      [ "custom_scrambler", "classgr_1_1scrambler__cpp_1_1custom__scrambler.html", "classgr_1_1scrambler__cpp_1_1custom__scrambler" ]
    ] ],
    [ "custom_scrambler_impl.h", "custom__scrambler__impl_8h.html", [
      [ "custom_scrambler_impl", "classgr_1_1scrambler__cpp_1_1custom__scrambler__impl.html", "classgr_1_1scrambler__cpp_1_1custom__scrambler__impl" ]
    ] ]
];