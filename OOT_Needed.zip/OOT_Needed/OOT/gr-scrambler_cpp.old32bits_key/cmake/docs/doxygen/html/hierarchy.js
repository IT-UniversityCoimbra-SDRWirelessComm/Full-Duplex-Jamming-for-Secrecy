var hierarchy =
[
    [ "block", null, [
      [ "gr::scrambler_cpp::custom_descrambler", "classgr_1_1scrambler__cpp_1_1custom__descrambler.html", [
        [ "gr::scrambler_cpp::custom_descrambler_impl", "classgr_1_1scrambler__cpp_1_1custom__descrambler__impl.html", null ]
      ] ],
      [ "gr::scrambler_cpp::custom_scrambler", "classgr_1_1scrambler__cpp_1_1custom__scrambler.html", [
        [ "gr::scrambler_cpp::custom_scrambler_impl", "classgr_1_1scrambler__cpp_1_1custom__scrambler__impl.html", null ]
      ] ]
    ] ]
];